// ===== CTA Button Pulse Effect =====
const ctaButton = document.querySelector(".cta");

setInterval(() => {
  ctaButton.classList.toggle("pulse");
}, 1800);

// ===== Smooth hover interaction for cards =====
const cards = document.querySelectorAll(".card");

cards.forEach(card => {
  card.addEventListener("mousemove", (e) => {
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotateX = (y - centerY) / 25;
    const rotateY = (centerX - x) / 25;

    card.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-6px)`;
  });

  card.addEventListener("mouseleave", () => {
    card.style.transform = "rotateX(0) rotateY(0)";
  });
});

// ===== Page Fade-in on Load =====
document.body.style.opacity = 0;

window.addEventListener("load", () => {
  document.body.style.transition = "opacity 1.2s ease";
  document.body.style.opacity = 1;
});

let vitalsRiskLevel = "LOW";

function checkVitals() {
  const bp = +document.getElementById("bp").value;
  const sugar = +document.getElementById("sugar").value;

  const result = document.getElementById("vitalsResult");
  const badge = document.getElementById("vitalsRisk");
  const text = document.getElementById("vitalsText");

  if (!bp || !sugar) {
    alert("Please enter all vitals.");
    return;
  }

  vitalsRiskLevel = "LOW";

  if (bp > 140 || sugar > 180) vitalsRiskLevel = "HIGH";
  else if (bp > 120 || sugar > 140) vitalsRiskLevel = "MEDIUM";

  badge.className = "risk-badge " + vitalsRiskLevel.toLowerCase();
  badge.innerText = `Vitals Risk: ${vitalsRiskLevel}`;

  text.innerText =
    vitalsRiskLevel === "LOW"
      ? "Vitals are within a safe range."
      : vitalsRiskLevel === "MEDIUM"
      ? "Vitals need monitoring."
      : "High risk detected. Medical consultation recommended.";

  result.classList.remove("hidden");
}

